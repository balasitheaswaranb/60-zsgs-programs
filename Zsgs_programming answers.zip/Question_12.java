package com.numbers;

/*Java Program to left rotate the elements of a multidimensional array.
*/
public class Question_12 {
	public static void main(String[] args) {
		double num = 7.50;
		System.out.format("%.2f", num);
	}

}
