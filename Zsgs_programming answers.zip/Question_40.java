package com.numbers;
//  Java Program to print the number of elements present in an array

public class Question_40 {
	 public static void main(String[] args) {  
	        int [] arr = new int [] {1, 113, 257, 758, 56};  
	        System.out.println("Number of elements present in given array: " + arr.length);  
	    }  

}
