package com.numbers;
// ) Program to Swap Two Numbers
public class Question_27 {
	 public static void main(String... args)
	 {
		 int a=20,b=30;
		 int temp=a;
		 a=b;
		 b=temp;
		 System.out.println("swapping of two number Previous value : a=20,b=30 and Swaped Value : "+"a="+a+","+"b="+b);
	 }
}
