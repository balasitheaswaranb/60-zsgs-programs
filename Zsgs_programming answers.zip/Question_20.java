package com.numbers;

public class Question_20 {
	public static void main(String[] args) {
		
		  int x=1;
		  x=x++*2+3*--x;
	      System.out.println("Value of x=x++*2+3*--x is "+x);
	}
}
